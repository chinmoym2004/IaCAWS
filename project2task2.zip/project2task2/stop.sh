#!/bin/bash
sudo init 6